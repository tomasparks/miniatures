                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2977517
Myst Planetarium by Cyan_Inc is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Celebrating the 25th anniversary of Myst! From the company that created Myst, the Myst Planetarium based on the 3D model from the original game.

# Print Settings

Rafts: Doesn't Matter
Supports: Yes
Resolution: 0.15mm
Infill: 15%

Notes: 
Model in image printed at 0.15mm at 36%.

Note: Because these STL files are modified versions of the actual original Myst models, and because we are new to 3D printing - there are some issues. Thanks for the community help... we'll happily update our files with better versions. And just FYI - our printed versions were all sliced with Cura 3.3.1. 

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/b2/ae/ed/ad/eb/3DPrint-Planetarium.jpg)