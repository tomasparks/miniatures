                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2977508
Myst Clocktower by Cyan_Inc is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Celebrating the 25th anniversary of Myst! From the company that created Myst, the Myst Clocktower based on the 3D model from the original game.

# Print Settings

Rafts: Doesn't Matter
Supports: Yes
Resolution: 0.15mm
Infill: 15%

Notes: 
Model in image printed at 0.15mm at 20%. Smaller prints will make wind vane too delicate to keep. Larger prints may allow keeping wind vane.

Note: Because these STL files are modified versions of the actual original Myst models, and because we are new to 3D printing - there are some issues. Thanks for the community help... we'll happily update our files with better versions. And just FYI - our printed versions were all sliced with Cura 3.3.1. 

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/0e/4c/12/0b/59/3DPrint-Clocktower.jpg)